<?php
$_['heading_title'] = 'MIXPLAT';

?>