<?php
// Text
$_['text_title'] = 'Банковской картой через MIXPLAT';
?>